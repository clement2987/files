from django.contrib import admin

from .models import *

admin.site.register(Message)
admin.site.register(Page)
admin.site.register(Quote_files)
admin.site.register(Quote_request)
admin.site.register(Past_work)

# Register your subscription models here.
admin.site.register(Payment)
admin.site.register(SubscriptionPlan)
admin.site.register(Subscription)
admin.site.register(Website)
admin.site.register(Customer)
admin.site.register(StripeCustomer)