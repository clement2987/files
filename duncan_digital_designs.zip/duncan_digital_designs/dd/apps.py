from django.apps import AppConfig


class DdConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dd'
