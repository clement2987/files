from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

# Create your models here.
class Message(models.Model):
    name = models.CharField(max_length=64)
    email = models.EmailField()
    Message = models.CharField(max_length=2000)
    submitted = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"message from {self.name}"

class Page(models.Model):
    tital = models.CharField(max_length=64)
    details = models.CharField(max_length=2000)

    def __str__(self):
        return self.tital

class Quote_files(models.Model):
    q_file = models.ImageField(upload_to='quote_files/') 

    def __str__(self):
        return self.q_file.name

class Quote_request(models.Model):
    name = models.CharField(max_length=64)
    email = models.EmailField()
    phone_number = models.CharField(max_length=12)
    website_goal = models.CharField(max_length=64)

    TYPE_CHOICES = [
        ('e-commerce', 'E-commerce'),
        ('dynamic', 'Dynamic Webapp'),
        ('static', 'Static Website'),
        ('unknown', 'Unknown'),
    ]


    type_of_website = models.CharField(max_length=32, choices=TYPE_CHOICES)
    description = models.CharField(max_length=2000, blank=True)
    pages = models.ManyToManyField(Page, related_name="quote_pages", blank=True)
    files = models.ManyToManyField(Quote_files, related_name="quote_files", blank=True)
    viewed = models.BooleanField(default=False)
    submitted = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.id} Quote from {self.name}"

class Past_work(models.Model):
    name = models.CharField(max_length=64)
    address = models.CharField(max_length=64)
    description = models.CharField(max_length=2000)
    screenshot = models.ImageField(upload_to='screenshots/')


"""
Payment: Tracks individual payment details, including whether the payment is part of a subscription.

SubscriptionPlan: Defines subscription plans, with monthly costs and billing dates. This makes it flexible if you later want to offer different subscription tiers.

Subscription: This tracks active subscriptions, linking each Customer and Website to a SubscriptionPlan. Payments are associated here, allowing you to see all payments made for a given subscription.

Website: Includes a boolean is_subscription to distinguish between one-time purchases and subscription-based services. price can be used as a one-time cost for non-subscription websites.

Customer: Holds customer information, associating them with websites and subscriptions.

Usage Flow
For a one-time purchase, create a Website entry with is_subscription=False and link it directly to the Customer.
For a subscription:
Create a Subscription entry and link it to the Customer and Website.
Periodically add Payment entries under Subscription.payments based on the SubscriptionPlan.
This setup allows for flexibility, whether you expand to different subscription plans or offer additional services.
"""
class Changes(models.Model):
    date_time = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    field = models.CharField(max_length=64)
    old_value = models.CharField(max_length=128)
    new_value = models.CharField(max_length=128)

    def __str__(self):
        local_time = timezone.localtime(self.date_time)  # Convert to Australia/Melbourne time
        formatted_time = local_time.strftime("%Y-%m-%d %H:%M:%S")  # Format the datetime
        return f"on {formatted_time} {self.user} changed {self.field} from {self.old_value} to {self.new_value}"


class Payment(models.Model):
    service = models.CharField(max_length=128)
    amount = models.FloatField()
    payment_date = models.DateTimeField(auto_now_add=True) #payment creation date. add date paid and date due
    date_paid = models.DateTimeField(null=True, blank=True) 
    is_subscription_payment = models.BooleanField(default=False)
    changes = models.ManyToManyField(Changes, blank=True)

    TYPE_CHOICES = [
        ('Paid', 'Paid'),
        ('Pending', 'Pending'),
        ('Overdue', 'Overdue'),
    ]
    status = models.CharField(max_length=8, choices=TYPE_CHOICES)

    def __str__(self):
        return f"Payment of ${self.amount} on {self.payment_date} for {self.service}"

class SubscriptionPlan(models.Model):
    name = models.CharField(max_length=64)
    monthly_cost = models.FloatField()
    billing_day = models.IntegerField()  # Day of the month for billing (1-31)
    changes = models.ManyToManyField(Changes, blank=True)
    stripe_price_id = models.CharField(max_length=64)

    def __str__(self):
        return f"{self.name} - ${self.monthly_cost}/month"

class Subscription(models.Model):
    customer = models.ForeignKey("Customer", on_delete=models.CASCADE)
    website = models.ForeignKey("Website", on_delete=models.CASCADE)
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.SET_NULL, null=True)
    start_date = models.DateField(default=timezone.now)
    end_date = models.DateField(blank=True, null=True)  # Optional end date
    active = models.BooleanField(default=True)
    payments = models.ManyToManyField(Payment, related_name="subscriptions", blank=True)
    stripe_active = models.BooleanField(default=False)
    changes = models.ManyToManyField(Changes, blank=True)

    def __str__(self):
        return f"Subscription for {self.customer} on {self.website}"


class Website(models.Model):
    url = models.CharField(max_length=64, blank=True)
    live = models.BooleanField(default=False)
    name = models.CharField(max_length=64)
    quote = models.ForeignKey("Quote_request", on_delete=models.SET_NULL, blank=True, null=True)
    is_subscription = models.BooleanField(default=False)  # Indicates if it's a subscription-based website
    price = models.FloatField()  # Price for one-time purchase (if not a subscription)
    additional_payments = models.ManyToManyField(Payment, related_name="additional_payments", blank=True)
    custom_email_domain = models.BooleanField(default=False)
    changes = models.ManyToManyField(Changes, blank=True)

    def __str__(self):
        return f"{self.name} - {'Subscription' if self.is_subscription else 'One-time purchase'}"

class Customer(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    websites = models.ManyToManyField(Website, related_name="customers", blank=True)
    subscriptions = models.ManyToManyField(Subscription, related_name="customers", blank=True)
    payments = models.ManyToManyField(Payment, related_name="customer_payments", blank=True)
    invitation_code = models.CharField(max_length=64, null=True, blank=True)
    name = models.CharField(max_length=64)
    changes = models.ManyToManyField(Changes, blank=True)

    def __str__(self):
        return f"Customer {self.name}"
    
    def unpaid_payment_count(self):
        return self.payments.exclude(status="Paid").count()
    
# stripe stuff
class StripeCustomer(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    stripe_customer_id = models.CharField(max_length=255, unique=True)
    subscription_object = models.ForeignKey(Subscription, on_delete=models.CASCADE)
    plan_active = models.BooleanField(default=False)
    plan_expires = models.BigIntegerField(null=True, blank=True)
    subscription_id = models.CharField(max_length=255, null=True, blank=True)

    def __str__(self):
        return f"{self.user.username}: {self.stripe_customer_id}"