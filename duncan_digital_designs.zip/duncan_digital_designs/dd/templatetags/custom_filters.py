from django import template

register = template.Library()

@register.filter
def my_getattr(obj, attr):
    """Fetch an attribute from an object dynamically"""
    return getattr(obj, attr)