from django.urls import path

from .views import standard_views, enquire_views, authentication_views, report_views, client_views, stripe_views, webhook_views, compliance_views, manager_views, seo_views


urlpatterns = [
    # Standard/Static Paths
    path("", standard_views.index, name="index"),
    path("information", standard_views.staticvdynamic, name="information"),
    path("about-me", standard_views.about_me, name="about_me"),
    path("create-page", standard_views.create_page, name="create_page"),
    path("past-projects", standard_views.past_projects, name="past_projects"),

    # Enquiries
    path("contact-me", enquire_views.contact, name="contact_me"),
    path("quote", enquire_views.quote, name="submit_quote"),

    # authentication
    path("login", authentication_views.login_view, name="login"),
    path("logout", authentication_views.logout_view, name="logout"),
    path("register/<str:invitation>", authentication_views.register_view, name="register"),

    # Reports
    path("pdf", report_views.generate_pdf, name="pdf"),
    path("pdf-s", report_views.generate_pdf_staff, name="pdf_s"),

    # clients
    path("dashboard", client_views.customer_dashboard, name="customer_dashboard"),
    path("customer_payments", client_views.customer_payments, name="customer_payments"),
    path("customer_payments/<int:website_id>", client_views.customer_payments, name="customer_payments_with_id"),

    # stripe
    path("payment-success", stripe_views.checkout_success, name="checkout_success"),
    path("payment-cancel", stripe_views.checkout_cancel, name="checkout_cancel"),
    path("make-payment", stripe_views.checkout_single, name="checkout_single"),
    path("make-subscription", stripe_views.checkout_sub, name="checkout_sub"),
    path("stripe-portal", stripe_views.portal, name="portal"),

    # webhook
    path("webhook/stripe", webhook_views.webhook, name='stripe_webkook'),

    # compliance
    path("privacy-policy", compliance_views.privacy_policy, name="privacy"),
    path("terms-and-conditions", compliance_views.terms, name="terms"),

    # management
    path("upload-past-page", manager_views.upload_past_project, name="new_past_project"),
    path("assets", manager_views.create_assets, name="create_assets"),
    path("customer-details/<int:customer_id>", manager_views.customer_details, name="customer_details"),
    path("payment-lists", manager_views.view_payments_for_customer, name="payment_lists"),
    path("view-and-change-model/<str:model_name>/<int:obj_id>", manager_views.view_and_update_fields, name="view_and_update_fields"),
    path("view_all_quote_request", manager_views.view_all_quote_request, name="view_all_quote_request"),
    path("view_quote_request/<int:quote_id>", manager_views.view_quote_request, name="view_quote_request"),
    path("manager-dashboard", manager_views.manager_dashboard, name="manager_dashboard"),  

    # SEO
    path("sitemap.xml", seo_views.sitemap_view, name="sitemap"),
    path("robots.txt", seo_views.robots_txt_view, name="robots"),
]
