document.getElementById('registerForm').addEventListener('submit', function(event) {
    let valid = true;

    // Validate Email
    const email = document.getElementById('email').value;
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        emailError.style.display = 'block';
        valid = false;
    } else {
        emailError.style.display = 'none';
    }

    // Validate Password Match
    const password = document.getElementById('password').value;
    const confirmation = document.getElementById('confirmation').value;
    const passwordError = document.getElementById('passwordError');
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
    if (!passwordPattern.test(password)) {
        passwordError.textContent = "Password must be at least 8 characters long and include uppercase, lowercase, number, and special character.";
        passwordError.style.display = 'block';
        valid = false;
    } else if (password !== confirmation) {
        passwordError.textContent = "Passwords do not match.";
        passwordError.style.display = 'block';
        valid = false;
    } else {
        passwordError.style.display = 'none';
    }

    // If validation fails, prevent form submission
    if (!valid) {
        event.preventDefault();
    }
});