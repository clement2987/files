const customerObject = document.getElementById("customer-object");
    customerObject.addEventListener("change", function() {
        const newCustomerName = document.getElementById("customer-name");
        if (customerObject.value === ""){
            newCustomerName.setAttribute("required", "required");
        } else {
            newCustomerName.removeAttribute("required");
        }
    })

    const isLive = document.getElementById("website-subscription");
    const planName = document.getElementById("subscription-plan-name");
    const planCost = document.getElementById("subscription-plan-cost");
    const planDay = document.getElementById("subscription-plan-day");
    const plan = document.getElementById("subscription-plan");

    // Event handler function
    function handlePlanChange() {
        if (plan.value === "") {
            planName.setAttribute("required", "required");
            planCost.setAttribute("required", "required");
            planDay.setAttribute("required", "required");
        } else {
            planName.removeAttribute("required");
            planCost.removeAttribute("required");
            planDay.removeAttribute("required");
        }
    }

    // Main event for `isLive` checkbox
    isLive.addEventListener("change", function() {
        if (isLive.checked) {
            handlePlanChange()
            plan.addEventListener("change", handlePlanChange);
        } else {
            plan.removeEventListener("change", handlePlanChange);
            planName.removeAttribute("required");
            planCost.removeAttribute("required");
            planDay.removeAttribute("required");
        }
    });