document.getElementById("site-information").addEventListener("input", function(){
    const counter = document.getElementById("site-information-counter");
    const textLength = this.value.length;
    counter.textContent = `${textLength.toLocaleString()} of 2,000 characters used`;
});



function addPage() {
const container = document.getElementById("pages-container");

// Create a new div for the page
const pageDiv = document.createElement("div");
pageDiv.className = "page-group";
pageDiv.innerHTML = `
    <label for="page-title">Page Title:</label>
    <input type="text" name="pages[title]" required>
    
    <label for="page-details">Page Details:</label>
    <textarea name="pages[details]" required maxlength="2000"></textarea>

    <button type="button" onclick="removePage(this)">Remove Page</button>
`;

container.appendChild(pageDiv);
}

function removePage(button) {
button.parentElement.remove();
}
