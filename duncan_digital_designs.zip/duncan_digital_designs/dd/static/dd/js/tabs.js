function openTab(evt, tabId) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => tab.style.display = 'none');

    // Remove active class from all tab links
    const tabLinks = document.querySelectorAll('.tab-link');
    tabLinks.forEach(link => link.classList.remove('active'));

    // Show the selected tab and add active class to the clicked button
    document.getElementById(tabId).style.display = 'block';
    evt.currentTarget.classList.add('active');
}
document.addEventListener("DOMContentLoaded", function() {
    const firstTabLink = document.querySelector('.tab-link');
    if (firstTabLink) {
        firstTabLink.click();
    }
});
