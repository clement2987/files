from django.shortcuts import redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.conf import settings

import stripe
stripe.api_key = settings.STRIPE_SECRET_KEY

from ..models import Customer, SubscriptionPlan, Subscription, Payment, StripeCustomer
from .tools import app_response

def checkout_success(request):
    return app_response(request, "Checkout Complete", "Thank you for your purchase, an email will be sent with your receipt, alternatively receipts can be downloaded from the dashboard.")


def checkout_cancel(request):
    return app_response(request, "Checkout Cancelled", "")


def checkout_sub(request):
    if request.method != 'POST':
        return HttpResponse("requests must be post", status=400)
    
    try:
        customer = Customer.objects.get(user=request.user.id)
    except Customer.DoesNotExist:
        return app_response(request, "Error", "Unable to locate user details. Please make sure you are logged in")
    
    try:
        subscription_plan = SubscriptionPlan.objects.get(id=int(request.POST['payment']))
    except SubscriptionPlan.DoesNotExist:
        return app_response(request, "Error", "Unable to locate subscription details. Please contact the website owner for assistance")

    try:
        subscription_object = Subscription.objects.get(id=int(request.POST['subscription']))
        if subscription_object.plan != subscription_plan:
            raise Subscription.DoesNotExist
        if subscription_object.customer != customer:
            raise Subscription.DoesNotExist
    except SubscriptionPlan.DoesNotExist:
        return app_response(request, "Error", "Unable to locate subscription details. Please contact the website owner for assistance")
    
    session = stripe.checkout.Session.create(
        customer_email=request.user.email,
        line_items= [
            {
                "price": subscription_plan.stripe_price_id,
                'quantity': 1
            },
            
        ],
        metadata={
            "type": "sub",
            "user": request.user.id,
            "sub": request.POST["subscription"], #TODO dont trust the front end
            "price": subscription_plan.monthly_cost
        },
        mode="subscription",
        success_url='http://127.0.0.1:8000/payment-success',
        cancel_url='http://127.0.0.1:8000/payment-cancel'
    )
    
    return redirect(session.url, code=303)


def checkout_single(request):
    if request.method != 'POST':
        return HttpResponse("requests must be post", status=400)

    try:
        customer = Customer.objects.get(user=request.user.id)
    except Customer.DoesNotExist:
        return app_response(request, "Error", "Unable to locate user details. Please make sure you are logged in")
        
    try:
        payment = Payment.objects.get(id=int(request.POST['payment']))
    except Payment.DoesNotExist:
        return app_response(request, "Error", "Unable to locate payment details. Please contact the website owner for assistance")
        
    if not customer.payments.filter(id=payment.id).exists():
        return app_response(request, "Error", "Unable to locate payment details. Please contact the website owner for assistance")
    
    session = stripe.checkout.Session.create(
        customer_email=request.user.email,
        line_items = [
            {
                "price_data": {
                    "currency": "aud",
                    "product_data": {
                        "name": "Website Hosting And Maintainence" if payment.is_subscription_payment else "website services"
                    },
                    "unit_amount": int(payment.amount*100),
                },
                "quantity": 1,
            },
        ],
        
        metadata={
            "type": "single",
            "payment_object": payment.id,
            "customer": customer.id
        },
        mode="payment",
        success_url='http://127.0.0.1:8000/payment-success',
        cancel_url='http://127.0.0.1:8000/payment-cancel'
    )
    
    return redirect(session.url, code=303)

@login_required
def portal(request):
    if request.method != 'POST':
        return HttpResponse("requests must be post", status=400)
    
    user = request.user
    stripe_user = get_object_or_404(StripeCustomer, subscription_object=request.POST["subscription"])
    if stripe_user.user != user:
        return app_response(request, "Error", "User does not match Subscription")
        

    session = stripe.billing_portal.Session.create(
        customer=stripe_user.stripe_customer_id,
        return_url='http://127.0.0.1:8000/'
    )
    return redirect(session.url, code=303)