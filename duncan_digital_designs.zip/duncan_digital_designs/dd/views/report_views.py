from django.contrib.auth.decorators import login_required
from django.http import FileResponse, HttpResponse

from ..models import Customer, Payment
from .dd_reports import generate_pdf_receipt
from .tools import staff_member_required

@login_required
def generate_pdf(request):
    customer = Customer.objects.get(user=request.user.id)
    payment = Payment.objects.get(id=int(request.POST["payment"]))
    if not customer.payments.filter(id=payment.id).exists():
        return HttpResponse(status=403)
    if payment.is_subscription_payment:
        subscription = payment.subscriptions.first()
        website = subscription.website
    else:
        website = payment.additional_payments.first()
    buffer = generate_pdf_receipt(payment, customer, website)

    return FileResponse(buffer, as_attachment=True, filename=f"invoice-{payment.id}.pdf")

@staff_member_required
def generate_pdf_staff(request):
    customer = Customer.objects.get(id=int(request.POST["customerId"]))
    payment = Payment.objects.get(id=int(request.POST["payment"]))
    if not customer.payments.filter(id=payment.id).exists():
        return HttpResponse(status=403)
    if payment.is_subscription_payment:
        subscription = payment.subscriptions.first()
        website = subscription.website
    else:
        website = payment.additional_payments.first()
    buffer = generate_pdf_receipt(payment, customer, website)

    return FileResponse(buffer, as_attachment=True, filename=f"invoice-{payment.id}.pdf")