from django.shortcuts import render, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.core.validators import validate_email
from django.db import IntegrityError
from django.core.exceptions import ValidationError

from .tools import is_secure_password, app_response
from ..models import Customer, User

def login_view(request):
    if request.method == "POST":
        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("manager_dashboard" if user.is_superuser else "customer_dashboard"))
        else:
            return app_response(request, "Unable To Login", "Invalid username and/or password")

    return render(request, "dd/authentication/login.html")

def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))

def register_view(request, invitation):
    if request.method != "POST":
        customer = get_object_or_404(Customer, invitation_code=invitation)
        if customer.user:
            return HttpResponseRedirect(reverse("login"))
        return render(request, "dd/authentication/register.html", {"invitation": invitation})
    
    username = request.POST["username"]
    email = request.POST["email"]
    first_name = request.POST["firstName"]
    last_name = request.POST["lastName"]
    password = request.POST["password"]
    confirmation = request.POST["confirmation"]

    if len(username) < 3 or len(first_name) < 3 or len(last_name) < 2:
        return app_response(request, "Invalid Name", "Name must be at least 3 characters long")

    try:
        validate_email(email)
    except ValidationError:
        return app_response(request, "Invalid Email", "")

    customer = get_object_or_404(Customer, invitation_code=invitation)

    if password != confirmation or not is_secure_password(password):
        return app_response(request, "Passwords Do Not Match", "")
    
    try:
        user = User.objects.create_user(
            username=username,
            email=email,
            first_name=first_name,
            last_name=last_name
        )
        user.set_password(password)  # Securely set the password
        user.save()

        customer.user = user
        customer.save()

        login(request, user)

        return HttpResponseRedirect(reverse("customer_dashboard")) #TODO make this the dashboard

    except IntegrityError:
        return app_response(request, "Error", "Username already exists. Please choose a different username.")
        

    except Exception as e:
        return app_response(request, "Error", f"An unexpected error occurred: {str(e)}")