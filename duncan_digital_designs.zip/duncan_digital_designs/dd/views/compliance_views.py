from django.shortcuts import render

def privacy_policy(request):
    return render(request, "dd/compliance/privacy.html")

def terms(request):
    return render(request, "dd/compliance/tandc.html")