from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.timezone import now
from django.core.mail import EmailMessage
from django.conf import settings

import stripe.webhook
import json

from ..models import Payment, User, Changes, Customer, Subscription, StripeCustomer
from .email_templates import *
from .dd_reports import generate_pdf_receipt
from .tools import convert_date_string

@csrf_exempt
def webhook(request):
    body = request.body#.decode('utf-8')
    signiture = request.META['HTTP_STRIPE_SIGNATURE']
    event = None

    try:
        event = stripe.Webhook.construct_event(body, signiture, settings.STRIPE_WEBHOOK_SECRET)
    except Exception as e:
        message = EmailMessage(
                subject="Payment Exception",
                body=str(e),
                from_email="info@duncandesigns.com.au",
                to=["info@duncandesigns.com.au"]
            )
        message.send()
        return HttpResponse(str(e), status=400)
    
    if event['type'] == "checkout.session.completed":
        session = event['data']['object']
        data = session["metadata"]


        if data['type'] == "single":
            payment = Payment.objects.get(id=data['payment_object'])
            payment.status = "Paid"

            stripe_user = User.objects.get(username="stripe")
            change = Changes(
                user=stripe_user,
                old_value="pending",
                new_value="paid"
            )
            change.save()
            payment.changes.add(change)
            payment.date_paid = now()
            payment.save()

            customer = Customer.objects.get(id=data["customer"])

            message = EmailMessage(
                subject=f"Invoice for Web Services – {payment.id}",
                body=single_payment_recipt(customer.user.first_name, payment.id, payment.service),
                from_email="info@duncandesigns.com.au",
                to=[customer.user.email]
            )

            if payment.is_subscription_payment:
                subscription = payment.subscriptions.first()
                website = subscription.website
            else:
                website = payment.additional_payments.first()

            pdf_buffer = generate_pdf_receipt(payment, customer, website)
            message.attach("payment_receipt.pdf", pdf_buffer.read(), "application/pdf")

            message.send()
            return HttpResponse(status=200)


        if data['type'] == "sub":
            #print(session)
            user_ = User.objects.get(id=session['metadata']['user'])
            sub_ = Subscription.objects.get(id=session['metadata']['sub'])

            customer_data, created = StripeCustomer.objects.get_or_create(user=user_, subscription_object=sub_)            

            if created:
                customer_data.stripe_customer_id = session['customer']
                customer_data.subscription_id = session.subscription
                customer_data.plan_active = True
                customer_data.plan_expires = None
                customer_data.save()

            customer_data.subscription_object.stripe_active = True
            customer_data.subscription_object.save()
            return HttpResponse(status=200)
            

    if event['type'] == "customer.subscription.updated":
        session = event['data']['object']
        #print(session)
        stripe_user = StripeCustomer.objects.get(subscription_id=session.id)
        stripe_user.plan_expires = session.cancel_at
        stripe_user.save()
        if session.cancel_at:
            stripe_user.subscription_object.end_date = convert_date_string(session.cancel_at)
        stripe_user.subscription_object.save()

        if session.cancel_at:
            message = EmailMessage(
                subject="Subscription Delete Pending",
                body=f"{stripe_user.subscription_object.website.url} has been cancelled",
                from_email="info@duncandesigns.com.au",
                to=["info@duncandesigns.com.au"]
            )
            message.send()
        return HttpResponse(status=200)
    
    if event['type'] == "customer.subscription.deleted":
        session = event['data']['object']
        stripe_user = StripeCustomer.objects.get(subscription_id=session.id)
        stripe_user.plan_active = False
        stripe_user.subscription_id = None
        stripe_user.save()
        # we will email myself and handle this manually for now
        message = EmailMessage(
            subject="Subscription Deleted",
            body=f"{stripe_user.subscription_object.website.url} has been deleted",
            from_email="info@duncandesigns.com.au",
            to=["info@duncandesigns.com.au"]
        )
        message.send()
        return HttpResponse(status=200)

    if event['type'] == "invoice.payment_succeeded":
        #print("invoiced")
        session = event['data']['object']
        
        stripe_customer = StripeCustomer.objects.get(subscription_id=session["subscription"])
        
        new_payment = Payment(
            service=f"Monthly subscription payment for {stripe_customer.subscription_object.website.name}",
            amount=session["amount_paid"]/100,
            is_subscription_payment=True,
            date_paid = now(),
            status="Paid"
        )
        new_payment.save()
        stripe_customer.subscription_object.payments.add(new_payment)
        stripe_customer.subscription_object.customer.payments.add(new_payment)

        message = EmailMessage(
            subject="Payment Received – Duncan Digital Designs Hosting Subscription",
            body=subscription_payment_recipt(stripe_customer.user.first_name),
            from_email="info@duncandesigns.com.au",
            to=[stripe_customer.user.email]
        )

        pdf_buffer = generate_pdf_receipt(new_payment, stripe_customer.subscription_object.customer, stripe_customer.subscription_object.website)
        message.attach("payment_receipt.pdf", pdf_buffer.read(), "application/pdf")

        message.send()

        return HttpResponse(status=200)

    
    if event['type'] == "invoice.payment_failed":
        session = event['data']['object']
        # just send myself an email for now
        message = EmailMessage(
            subject="Payment Failed",
            body=json.dumps(session, indent=4),
            from_email="info@duncandesigns.com.au",
            to=["info@duncandesigns.com.au"]
        )
        message.send()
        return HttpResponse(status=200)

    # send myself an email with the failed event type
    message = EmailMessage(
            subject="Payment Failed",
            body=json.dumps(event, indent=4),
            from_email="info@duncandesigns.com.au",
            to=["info@duncandesigns.com.au"]
        )
    message.send()
    return HttpResponse(status=500)