from django.http import HttpResponse
from django.urls import reverse
from django.utils.timezone import now


def sitemap_view(request):
    urls = [
        {"loc": "https://duncandesigns.com.au/", "priority": "1.0"},
        {"loc": f"https://duncandesigns.com.au{reverse('about_me')}", "priority": "0.8"},
        {"loc": f"https://duncandesigns.com.au{reverse('contact_me')}", "priority": "0.8"},
        {"loc": f"https://duncandesigns.com.au{reverse('past_projects')}", "priority": "0.8"},
        {"loc": f"https://duncandesigns.com.au{reverse('create_page')}", "priority": "0.7"},
        {"loc": f"https://duncandesigns.com.au{reverse('submit_quote')}", "priority": "0.7"},
        {"loc": f"https://duncandesigns.com.au{reverse('privacy')}", "priority": "0.5"},
        {"loc": f"https://duncandesigns.com.au{reverse('terms')}", "priority": "0.5"},
    ]

    sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n'
    sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'

    for url in urls:
        sitemap += f"""  
        <url>
            <loc>{url['loc']}</loc>
            <lastmod>{now().date()}</lastmod>
            <priority>{url['priority']}</priority>
        </url>
        """

    sitemap += '</urlset>'    
    return HttpResponse(sitemap, content_type="application/xml")

def robots_txt_view(request):
    content = """User-agent: *
Disallow: /login
Disallow: /fourscreens
Disallow: /pdf
Disallow: /pdf-s
Disallow: /dashboard
Disallow: /customer_payments
Disallow: /payment-success
Disallow: /payment-cancel
Disallow: /make-payment
Disallow: /make-subscription
Disallow: /stripe-portal
Disallow: /webhook
Disallow: /upload-past-page
Disallow: /assets
Disallow: /customer-details/
Disallow: /payment-lists
Disallow: /view-and-change-model/
Disallow: /view_all_quote_request
Disallow: /view_quote_request/
Disallow: /manager-dashboard

Sitemap: {scheme}://{host}/sitemap.xml
""".format(scheme=request.scheme, host=request.get_host())
    return HttpResponse(content, content_type="text/plain")