from django.shortcuts import render
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth import REDIRECT_FIELD_NAME
from django.core.exceptions import ValidationError
import PIL
from datetime import datetime
import re


def staff_member_required(
    function=None, redirect_field_name=REDIRECT_FIELD_NAME, login_url=None
):
    """
    Decorator for views that checks that the user is logged in, redirecting
    to the log-in page if necessary.
    """
    actual_decorator = user_passes_test(
        lambda u: u.is_staff,
        login_url=login_url,
        redirect_field_name=redirect_field_name,
    )
    if function:
        return actual_decorator(function)
    return actual_decorator

def app_response(request, title, message, exrea=None):
    return render(request, "dd/layouts/response.html", {
        "responce": title,
        "message": message,
        "extra": exrea
    })

def convert_date_string(d):
    date = datetime.fromtimestamp(d)
    return date.date()


def check64(text):
    if len(text) > 64:
        text = text[:64]
    return text

def check2k(text):
    if len(text) > 2000:
        text = text[:2000]
    return text

def check12(text):
    if len(text) > 12:
        text = text[:12]
    return text

def validate_image(image):
    # Check file type
    allowed_types = ['image/jpeg', 'image/png', 'image/gif']
    if image.content_type not in allowed_types:
        raise ValidationError("Only JPEG, PNG, and GIF images are allowed.")

    # Check file size
    max_size_kb = 2048  # 2 MB
    if image.size > max_size_kb * 1024:
        raise ValidationError("Image file size may not exceed 2 MB.")

    # Check dimensions
  
    try:
        img = PIL.Image.open(image)
        img.verify()  # Ensures it's a valid image
        img = PIL.Image.open(image)  # Re-open to get dimensions
        width, height = img.size
        if width > 1920 or height > 1080:
            raise ValidationError("Image dimensions may not exceed 1920x1080 pixels.")
    except (IOError, SyntaxError):
        raise ValidationError("The uploaded file is not a valid image.")


def is_secure_password(password):
    """Checks if a password meets security requirements."""
    if len(password) < 8:
        return False

    if not re.search(r"[A-Z]", password):
        return False

    if not re.search(r"[a-z]", password):
        return False

    if not re.search(r"\d", password):
        return False

    if not re.search(r"[!@#$%^&*()\-_=+<>?/]", password):
        return False

    return True