from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_LEFT, TA_RIGHT
from io import BytesIO

from django.conf import settings

import os
from datetime import timedelta

def generate_pdf_receipt(payment, customer, website):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []

    # Header with logo and right-aligned text
    logo_path = os.path.join(settings.STATIC_ROOT, 'dd/images/logosmallblue.jpg')
    logo = None
    if os.path.exists(logo_path):
        logo = Image(logo_path, width=2*inch, height=1*inch)

    # Right-aligned header text
    styles["Title"].alignment = TA_RIGHT
    header_text = [
        Paragraph("Duncan Digital Designs", styles['Title']),
        Paragraph("A.B.N 82 327 263 078", styles['Normal']),
        Paragraph("info@duncandesigns.com.au | +61 0433 496 284", styles['Normal']),
        Paragraph("https://duncandesigns.com.au", styles['Normal']),
    ]

    # Combine logo and header text in a table
    header_table_data = [
        [logo, Table([[cell] for cell in header_text], style=[('ALIGN', (0, 0), (-1, -1), 'RIGHT')])]
    ]
    header_table = Table(header_table_data, colWidths=[2.5*inch, None])
    header_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
    ]))
    elements.append(header_table)
    elements.append(Spacer(1, 30))

    # Section for customer details
    customer_details = [
        Paragraph(customer.name, styles['Normal']),
        Paragraph(customer.user.email, styles['Normal']),
    ]
    customer_table_data = [
        [Table([[cell] for cell in customer_details], style=[('ALIGN', (0, 0), (-1, -1), 'LEFT')])]
    ]
    customer_table = Table(customer_table_data, colWidths=[2*inch, None])
    customer_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ALIGN', (0, 0), (0, 0), 'LEFT'),
    ]))
    elements.append(customer_table)
    elements.append(Spacer(1, 30))

    # heading for recipt or invoice
    styles["Title"].alignment = TA_LEFT
    #title = ("Payment Receipt" if payment.status == 'Paid' else "Payment Invoice") + "# " + str(payment.id)
    title = "Payment Invoice" + "# " + str(payment.id)
    elements.append(Paragraph(title, styles['Title']))
    elements.append(Spacer(1, 30))
    styles["Normal"].alignment = TA_LEFT
    #title = ("Payment Receipt" if payment.status == 'Paid' else "Payment Invoice") + "# " + str(payment.id)
    title = "date issued" + ": " + payment.payment_date.strftime('%Y-%m-%d')
    elements.append(Paragraph(title, styles['Normal']))
    elements.append(Spacer(1, 30))

    # Payment details
    payment_data = [
        ["SERVICE", "WEBSITE", "DATE DUE", "STATUS", "AMOUNT"],
        [payment.service, website.url, (payment.payment_date + timedelta(days=7)).strftime('%Y-%m-%d'), payment.status if payment.status == "Paid" else "Unpaid", f'${payment.amount:.2f}'],
        ["","","", "TOTAL",  f'${payment.amount:.2f}']
        # ['Amount', f'${payment.amount:.2f}'],
        # ['Date', payment.payment_date.strftime('%Y-%m-%d %H:%M')],
        # ['Status', payment.status],
        # ['Subscription Payment', 'Yes' if payment.is_subscription_payment else 'No']
    ]

    table = Table(payment_data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (0,0), colors.lightskyblue),
        ('TEXTCOLOR', (0,0), (-1,0), colors.black),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 12),
        ('BOTTOMPADDING', (0,0), (-1,-1), 12),
        ('BACKGROUND', (-1,-1), (-1,-1), colors.gainsboro),
        ('GRID', (0,0), (-1,-1), 1, colors.black)
    ]))
    
    elements.append(table)

    title = "Please log into your account at https://duncandesigns.com.au to make a payment. If there are any issues please email at info@duncandesigns.com.au"
    elements.append(Paragraph(title, styles['Normal']))
    elements.append(Spacer(1, 30))

    # Build PDF
    doc.build(elements)
    buffer.seek(0)
    return buffer