def single_payment_invoice(name, payment_no, service):
    return (
        f"Dear {name},\n\n"
        f"Thank you for choosing Duncan Digital Designs for {service}. Attached to this email, you will find Invoice #{payment_no}.\n"
        f"You can make payment by logging into your account https://duncandigital/login. If you have any questions or require any modifications, please feel free to reach out.\n"
        f"I appreciate your business and look forward to working with you again.\n\n"
        f"Regards\n\n"
        f"Seth Duncan\n"
        f"Duncan Digital Designs"
    )

def single_payment_recipt(name, payment_no, service):
    return (
        f"Dear {name},\n\n"
        f"Thank you for payment to Duncan Digital Designs for {service}. Attached to this email, you will find Invoice #{payment_no}.\n"
        f"If you have any questions or require any modifications, please feel free to reach out.\n"
        f"I appreciate your business and look forward to working with you again.\n\n"
        f"Regards\n\n"
        f"Seth Duncan\n"
        f"Duncan Digital Designs"
    )

def subscription_payment_recipt(name):
    return (
        f"Dear {name},\n\n"
        f"Your monthly payment for the Duncan Digital Designs Web Hosting subscription has been successfully received. Thank you for your continued trust in the service!\n"
        f"A copy of your invoice is attached for your records. If you have any questions or need assistance, feel free to reach out.\n"
        f"Thanks again for your business—I appreciate you!\n\n"
        f"Regards\n\n"
        f"Seth Duncan\n"
        f"Duncan Digital Designs"
    )
