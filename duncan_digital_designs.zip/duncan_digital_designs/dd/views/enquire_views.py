from django.shortcuts import render
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.core.mail import EmailMessage

from ..models import Message, Quote_files, Quote_request, Page
from .tools import app_response, check12, check2k, check64, validate_image

# Create your views here.
def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        message_text = request.POST.get('message')

        try:
            validate_email(email)
        except ValidationError:
            return app_response(request, "Error", "Please enter a valid email address. Use the back button to avoid losing your work so far")
            
        
        try:
            message = Message(
                name=name,
                email=email,
                Message=message_text
            )
            message.save()
        except Exception as e:
            return app_response(request, "Error", "Message failed to send")
        
        message = EmailMessage(
                subject="New Message",
                body=f"message from {name}\n\nsender email: {email}\n\n message body: {message_text}",
                from_email="info@duncandesigns.com.au",
                to=["info@duncandesigns.com.au"]
            )
        message.send()
        
        return app_response(request, "Success", "Message sent successfully")
    return render(request, "dd/enquire/contact.html")


def quote(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone number')
        purpose = request.POST.get('purpose')

        dynamic = request.POST.get('dynamic')
        site_information = request.POST.get('site-information', '')

        try:
            validate_email(email)
        except ValidationError:
            return app_response(request, "Error", "Please enter a valid email address. Use the back button to avoid losing your work so far")
            
        
        name = check64(name)
        phone_number = check12(phone_number)
        purpose = check64(purpose)
        site_information = check2k(site_information)

        new_quote = Quote_request(
            name=name,
            email=email,
            phone_number=phone_number,
            website_goal=purpose,
            type_of_website=dynamic,
            description=site_information
        )
        new_quote.save()
        

        titles = request.POST.getlist('pages[title]')
        details = request.POST.getlist('pages[details]')        

        # Combining titles and details into a list of dictionaries
        pages = [{'title': title, 'details': detail} for title, detail in zip(titles, details)]

        for page in pages:
            title = page['title']
            details = page['details']
            title = check64(title)
            details = check2k(details)
            new_page = Page(
                tital=title,
                details=details
            )
            new_page.save()
            new_quote.pages.add(new_page)

        image_files = request.FILES.getlist("images[]")
        file_issues = []
        for image in image_files:
            try:
                validate_image(image)

                f = Quote_files(q_file=image)
                f.save()
                new_quote.files.add(f)
            except ValidationError as e:
                report = dict()
                report["name"] = image.name
                report["message"] = str(e)
                file_issues.append(report)

        message = EmailMessage(
                subject="New quote request",
                body=f"new quote request received",
                from_email="info@duncandesigns.com.au",
                to=["info@duncandesigns.com.au"]
            )
        message.send()

        return app_response(request, "Success", "Quote submitted successfully. I will get back to you shortly", file_issues)
        
        
    return render(request, "dd/enquire/submit-quote.html")