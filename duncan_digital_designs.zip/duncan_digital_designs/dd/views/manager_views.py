from django.shortcuts import render, get_object_or_404
from django.apps.registry import apps
from django.db.models import Sum


from .tools import app_response, staff_member_required
from ..models import Past_work, Customer, Website, Quote_request, Subscription, SubscriptionPlan, Payment, Changes


@staff_member_required
def upload_past_project(request):
    if request.method == "POST":
        name = request.POST.get("name")
        address = request.POST.get("address")
        description = request.POST.get("description")
        image_file = request.FILES.get("image")

        project = Past_work(
            name=name,
            address=address,
            description=description,
            screenshot=image_file
        )
        project.save()

        return app_response(request, "project saved successfully", "")
    return render(request, "dd/manager/upload-project.html")


@staff_member_required
def create_assets(request):
    if request.method == "POST":
        # get or create customer object
        customer_id = request.POST.get("customer-object")
        if customer_id != "":
            try:
                customer = Customer.objects.get(id=int(customer_id))
            except Customer.DoesNotExist:
                return app_response(request, "Error", "Invalid customer id")
        else:
            customer_name = request.POST.get("name")
            if customer_name == "":
                return app_response(request, "Error", "Invalid customer name")
            customer = Customer.objects.create(name=customer_name)

        # get website details
        website_url = request.POST.get("website-url")
        website_name = request.POST.get("website-name")
        website_price = request.POST.get("website-price")
        website_live = request.POST.get("website-live") == "on"
        website_subscription = request.POST.get("website-subscription") == "on"
        website_email = request.POST.get("website-email") == "on"
        website_quote_id = request.POST.get("website-quote")

        website = Website.objects.create(
            url=website_url,
            live=website_live,
            name=website_name,
            is_subscription=website_subscription,
            custom_email_domain=website_email,
            price=0 if website_price == "" else float(website_price) 
        )
        if website_quote_id != "":
            try:
                quote = Quote_request.objects.get(id=int(website_quote_id))
                website.quote = quote
                website.save()
            except Quote_request.DoesNotExist:
                return app_response(request, "Error", "Invalid Quote id")
        customer.websites.add(website)
        if website_subscription == False:
            return app_response(request, "Success", "Website saved without subscription")       
        
        subscription = Subscription.objects.create(
            customer=customer,
            website=website,
            active = request.POST.get("subscription-active") == "on"
        )
        customer.subscriptions.add(subscription)

        subscription_plan_id = request.POST.get("subscription-plan")
        if subscription_plan_id == "":
            subscription_plan_name = request.POST.get("subscription-plan-name")
            subscription_plan_cost = request.POST.get("subscription-plan-cost")
            subscription_plan_day = request.POST.get("subscription-plan-day")
            subscription_plan_stripe = request.POST.get("subscription-plan-stripe")
            subscription_plan = SubscriptionPlan.objects.create(
                name=subscription_plan_name,
                monthly_cost=subscription_plan_cost,
                billing_day=subscription_plan_day,
                stripe_price_id=subscription_plan_stripe
            )
        else:
            try:
                subscription_plan = SubscriptionPlan.objects.get(id=int(subscription_plan_id))
            except SubscriptionPlan.DoesNotExist:
                return app_response(request, "Error", "Invalid subscription plan")
        subscription.plan = subscription_plan
        subscription.save()
        return app_response(request, "Success", "Website saved with subscription")
        

    if "qr" in request.GET:
        qr_id = request.GET["qr"]
        try:
            quote = Quote_request.objects.get(id=int(qr_id))
        except Quote_request.DoesNotExist:
            quote = None
        except ValueError:
            quote = None
    else:
        quote = None

    context = {
        "quote": quote,
        "subscription_plans": SubscriptionPlan.objects.all(),
        "customers": Customer.objects.all(),
        "quotes": Quote_request.objects.all() if quote is None else None
    }

    return render(request, "dd/manager/assets.html", context)


@staff_member_required
def customer_details(request, customer_id):
    if request.method == "POST":
        service = request.POST["service"]
        amount = request.POST["amount"]
        object = request.POST["object"]
        owner = request.POST["owner"]

        customer = Customer.objects.get(id=int(customer_id))
        if owner == "website":
            target_website = Website.objects.get(id=object)
            new_payment = Payment(
                service=service,
                amount = amount,
                status="Pending"
            )
            new_payment.save()
            customer.payments.add(new_payment)
            target_website.additional_payments.add(new_payment)
        else:
            target_subscription = Subscription.objects.get(id=object)
            new_payment = Payment(
                service=service,
                amount = amount,
                is_subscription_payment=True,
                status="Pending"
            )
            new_payment.save()
            customer.payments.add(new_payment)
            target_subscription.payments.add(new_payment)

    try:
        customer = Customer.objects.get(id=int(customer_id))
    except Customer.DoesNotExist:
        return app_response(request, "Error", "No customer matching the requested id")
    
    website_pairs = list()
    websites = customer.websites.all()
    subscriptions = customer.subscriptions.all()
    for website in websites:
        pair = {
            "website": website,
            "subsctiption": None
        }
        for sub in subscriptions:
            if sub.website == pair['website']:
                pair['subsctiption'] = sub
        website_pairs.append(pair)
    
    context = {
        "customer": customer,
        "websites": website_pairs,
        "unpaid_invoices": customer.payments.exclude(status="Paid").count()
    }

    return render(request, "dd/manager/customer-details.html", context)

@staff_member_required
def view_payments_for_customer(request):
    if request.method != "POST":
        return app_response(request, "Error", "Request must be post")
    
    my_filter = request.POST["filter"]
    customer_id = request.POST["customer_id"]

    customer = Customer.objects.get(id=customer_id)
    if my_filter == "all":
        payments = customer.payments.all()
    elif my_filter == "unpaid":
        payments = customer.payments.exclude(status="Paid")
    elif my_filter == "website":
        website = customer.websites.get(id=int(request.POST["website"]))
        payments = website.additional_payments.all()
    elif my_filter == "subscription":
        subscription = customer.subscriptions.get(id=int(request.POST["subscription"]))
        payments = subscription.payments.all()

    return render(request, "dd/manager/payments-list.html", {"payments": payments, "customer_id": customer.id})


@staff_member_required
def view_and_update_fields(request, model_name, obj_id):
    model_class = apps.get_model("dd", model_name)

    if not model_class:
        return app_response(request, "Error: invalid model name", "")
    
    model_instance = get_object_or_404(model_class, id=obj_id)
    fields = [field.name for field in model_class._meta.get_fields() if field.concrete and not field.auto_created]

    if request.method == "POST":
        for field in fields:
            if field in request.POST:
                change = Changes(
                    user=request.user,
                    field=field,
                    old_value=str(getattr(model_instance, field)),
                    new_value=request.POST[field]
                )
                change.save()
                setattr(model_instance, field, request.POST[field])  # Update the value
                model_instance.changes.add(change)
                
        model_instance.save()  # Save changes to the database

    context = {
        "model": model_instance,
        "fields": fields,
        "model_name": model_name,
        "changes": model_instance.changes.all()
    }
    return render(request, "dd/manager/view-and-update.html", context)


@staff_member_required
def view_all_quote_request(request):    
    qr = Quote_request.objects.all().order_by('-id')    
    context = {
        "quote": qr,
        
    }
    return render(request, "dd/manager/quote-request-all.html", context)

@staff_member_required
def view_quote_request(request, quote_id):
    try:
        qr = Quote_request.objects.get(id=int(quote_id))
    except Quote_request.DoesNotExist:
        return app_response(request, "Error", f"No quote request with id {quote_id}")
    
    if request.method == "POST" and "mark_viewed" in request.POST:
        qr.viewed = True
        qr.save()

    connected_website = Website.objects.filter(quote=qr)
    
    context = {
        "quote": qr,
        "images": qr.files.all(),
        "pages": qr.pages.all(),
        "connected_website": connected_website,
    }
    return render(request, "dd/manager/quote-request.html", context)


@staff_member_required
def manager_dashboard(request):
    customers = Customer.objects.all()
    websites = Website.objects.all()
    subscriptions = Subscription.objects.all()
    subscription_plans = SubscriptionPlan.objects.all()

    total_unpaid_payments = Payment.objects.exclude(status="Paid").count()
    total_unpaid_amount = Payment.objects.exclude(status="Paid").aggregate(Sum("amount"))["amount__sum"] or 0
    total_paid_amount = Payment.objects.filter(status="Paid").aggregate(Sum("amount"))["amount__sum"] or 0
    total_payment_amount = total_paid_amount+total_unpaid_amount

    quote_requests_unread = Quote_request.objects.filter(viewed=False).count()

    context = {
        "customers": customers,
        "websites": websites,
        "subscriptions": subscriptions,
        "subscription_plans": subscription_plans,
        "total_unpaid_payments": total_unpaid_payments,
        "total_unpaid_amount": total_unpaid_amount,
        "total_paid_amount": total_paid_amount,
        "total_payment_amount": total_payment_amount,
        "quote_requests_unread": quote_requests_unread,
        }
    
    return render(request, "dd/manager/manager-dashboard.html", context)