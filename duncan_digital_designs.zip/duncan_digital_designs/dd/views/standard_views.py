from django.shortcuts import render

from ..models import Past_work

# Create your views here.
def index(request):
    return render(request, "dd/standard/index.html", {"home": True})

def staticvdynamic(request):
    return render(request, "dd/standard/staticvsdynamic.html")

def about_me(request):
    return render(request, "dd/standard/about-me.html")

def create_page(request):
    return render(request, "dd/standard/create-page.html")

def past_projects(request):
    projects = Past_work.objects.all()
    return render(request, "dd/standard/past-projects.html", {"projects": projects})