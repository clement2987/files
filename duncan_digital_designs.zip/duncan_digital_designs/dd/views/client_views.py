from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from ..models import Customer, Website, Subscription
from .tools import app_response

@login_required
def customer_dashboard(request):
    try:
        customer = Customer.objects.get(user=request.user)
        
    except Customer.DoesNotExist:
        return app_response(request, "Unable to find customer details", "Please contact the site owner to get the issue resolved")
    
    payment_count = customer.payments.exclude(status="Paid").count()
    website_pairs = list()
    websites = customer.websites.all()
    subscriptions = customer.subscriptions.all()
    for website in websites:
        pair = {
            "website": website,
            "subsctiption": None
        }
        for sub in subscriptions:
            if sub.website == pair['website']:
                pair['subsctiption'] = sub
        website_pairs.append(pair)

    context = {
        "customer": customer,
        "websites": website_pairs,
        "unpaid_payments": payment_count
    }
    return render(request, "dd/client/dashboard.html", context)


@login_required
def customer_payments(request, website_id=None):
    try:
        customer = Customer.objects.get(user=request.user)
        
    except Customer.DoesNotExist:
        return app_response(request, "Unable to find customer details", "")
    
    if website_id and website_id > 0:
        payments = list()
        try:
            website = customer.websites.get(id=website_id)
        except Website.DoesNotExist:
            return app_response(request, "Unable to find website payment details", "Invalid website ID")
        
        if website.is_subscription:
            try:
                plan = Subscription.objects.get(customer=customer, website=website_id)
            except Subscription.DoesNotExist:
                return app_response(request, "Unable to find website payment details", "Invalid website ID")
            except Subscription.MultipleObjectsReturned:
                return app_response(request, "Unable to find website payment details", "Invalid website ID")
            plan_payments = plan.payments.all()
            payments.extend(plan_payments)
        
        additional_payments = website.additional_payments.all()
        payments.extend(additional_payments)
    elif website_id == 0:
        payments = customer.payments.exclude(status="Paid")
    else:
        payments = customer.payments.all()

    return render(request, "dd/client/customers-payments.html", {"payments": payments})